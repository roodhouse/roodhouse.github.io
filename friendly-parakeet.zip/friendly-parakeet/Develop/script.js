// Assignment code here


// Get references to the #generate element
var generateBtn = document.querySelector("#generate");

// Write password to the #password input
function writePassword() {
  var password = generatePassword();
  function generatePassword() {
    
    // length section
      var passwordLength = 8;
      console.log(passwordLength);
      console.log(typeof passwordLength);
      var lengthPrompt = prompt("Enter a length between 8 and 128 characters");
      if(lengthPrompt >= 8 && lengthPrompt <= 128) {
        alert('Thank you for obeying');
        console.log(lengthPrompt);
        passwordLength = Number(lengthPrompt);
      } else {
        alert('Don\'t be salty.');
        console.log(lengthPrompt);
      };
     // end length section

     // character types section
     
     var lowerCase;
     var upperCase;
     var numeric;
     var specialCharacters;
     var userNumberOfVariables = 0;
     console.log(userNumberOfVariables);
     
     // lowercase 
     console.log(lowerCase); // testing variable value 
     console.log(typeof lowerCase); // test that variable is undefined type 
      function lowerPrompt() {
        var userInput = prompt("Would you like to use lowercase letters (y or n)?");
        if(userInput === 'y' || userInput === 'yes' || userInput === 'Y' || userInput === 'YES') {
            console.log(userInput);
            lowerCase = true; // set variable lowercase to true
            console.log(lowerCase); // confirming variable value has changed to true
            console.log(typeof lowerCase); // confirming variable type is now boolean
            userNumberOfVariables++;
            console.log(userNumberOfVariables);
        } 
        else if(userInput === 'n' || userInput === 'no' || userInput === 'N' || userInput === 'NO') {
          console.log(userInput);
          lowerCase = false; // set variable lowercase to true
          console.log(lowerCase); // confirming variable value has changed to true
          console.log(typeof lowerCase); // confirming variable type is now boolean
        }
        else {
          console.log('Failed instructions');
          alert('Please obey');
          lowerPrompt();
        }
      }
      lowerPrompt();

     // uppercase 
     console.log(upperCase); // testing variable value 
     console.log(typeof upperCase); // test that variable is undefined type 
      function upperPrompt() {
        var userInput = prompt("Would you like to use uppercase letters (y or n)?");
        if(userInput === 'y' || userInput === 'yes' || userInput === 'Y' || userInput === 'YES') {
            console.log(userInput);
            upperCase = true; // set variable lowercase to true
            console.log(upperCase); // confirming variable value has changed to true
            console.log(typeof upperCase); // confirming variable type is now boolean
            userNumberOfVariables++;
            console.log(userNumberOfVariables);
        } 
        else if(userInput === 'n' || userInput === 'no' || userInput === 'N' || userInput === 'NO') {
          console.log(userInput);
          upperCase = false; // set variable lowercase to true
          console.log(upperCase); // confirming variable value has changed to true
          console.log(typeof upperCase); // confirming variable type is now boolean
        }
        else {
          console.log('Failed instructions');
          alert('Stop failing.');
          upperPrompt();
        }
      }
      upperPrompt();

      // numeric
      console.log(numeric); // testing variable value 
      console.log(typeof numeric); // test that variable is undefined type 
       function numericPrompt() {
         var userInput = prompt("Would you like to use numbers (y or n)?");
         if(userInput === 'y' || userInput === 'yes' || userInput === 'Y' || userInput === 'YES') {
             console.log(userInput);
             numeric = true; // set variable lowercase to true
             console.log(numeric); // confirming variable value has changed to true
             console.log(typeof numeric); // confirming variable type is now boolean
             userNumberOfVariables++;
            console.log(userNumberOfVariables);
         } 
         else if(userInput === 'n' || userInput === 'no' || userInput === 'N' || userInput === 'NO') {
           console.log(userInput);
           numeric = false; // set variable lowercase to true
           console.log(numeric); // confirming variable value has changed to true
           console.log(typeof numeric); // confirming variable type is now boolean
         }
         else {
           console.log('Failed instructions');
           alert('Stop failing.');
           numericPrompt();
         }
       }
       numericPrompt();  

       // special characters
      console.log(specialCharacters); // testing variable value 
      console.log(typeof specialCharacters); // test that variable is undefined type 
       function specialCharactersPrompt() {
         var userInput = prompt("Would you like to use special characters (y or n)?");
         if(userInput === 'y' || userInput === 'yes' || userInput === 'Y' || userInput === 'YES') {
             console.log(userInput);
             specialCharacters = true; // set variable lowercase to true
             console.log(specialCharacters); // confirming variable value has changed to true
             console.log(typeof specialCharacters); // confirming variable type is now boolean
             userNumberOfVariables++;
            console.log(userNumberOfVariables);
         } 
         else if(userInput === 'n' || userInput === 'no' || userInput === 'N' || userInput === 'NO') {
           console.log(userInput);
           specialCharacters = false; // set variable lowercase to true
           console.log(specialCharacters); // confirming variable value has changed to true
           console.log(typeof specialCharacters); // confirming variable type is now boolean
         }
         else {
           console.log('Failed instructions');
           alert('Stop failing.');
           specialCharactersPrompt();
         }
       }
       specialCharactersPrompt(); 

     // end character types section


     // recording new variables values to the console
     console.log('User wants a password that is ' + passwordLength + ' characters long.');
     console.log('Lowercase: ' + lowerCase);
     console.log('Uppercase: ' + upperCase);
     console.log('Numeric: ' + numeric);
     console.log('Special Characters: ' + specialCharacters);
     console.log(userNumberOfVariables);

    var amtOfCharactersPerType = passwordLength / userNumberOfVariables;
    console.log(amtOfCharactersPerType); 

    // Do something with new variable values here

    if (lowerCase == true ) { // randomly select amtOfCharactersPerType from lowercase letters a-z 
      

      

        function randomLowerLetter() { 
          var lowerLetters = [
            'a', 'b', 'c', 'd', 'e',
            'f', 'g', 'h', 'i', 'j',
            'k', 'l', 'm', 'n', 'o',
            'p', 'q', 'r', 's', 't',
            'u', 'v', 'w', 'x', 'y',
            'z'];

          lowerLetters = lowerLetters[Math.floor(Math.random() * 25)];
          console.log(lowerLetters);
          
        };
        
        randomLowerLetter();

        for (i = randomLowerLetter(); i <= amtOfCharactersPerType; i++) { // stopped here!!! loop is not looping... 
          randomLowerLetter();
        };
 
      console.log('Lowercase was true, below are the letters');
      
    }

     // solutions here

    //  options:
    //  all

    //  lower only
    //  lower upper
    //  lower numeric
    //  lower special
    //  lower upper numeric
    //  lower upper special
    //  lower numeric special

    //  upper only
    //  upper numeric
    //  upper special 
    //  upper 
    //  numeric only
    //  numeric special

    //  special only


    
      // prompt("Click this button", "small letters");
      return 'john ' + passwordLength;
  };
  var passwordText = document.querySelector("#password");

  passwordText.value = password;

};


// Add event listener to generate button
generateBtn.addEventListener("click", writePassword);
